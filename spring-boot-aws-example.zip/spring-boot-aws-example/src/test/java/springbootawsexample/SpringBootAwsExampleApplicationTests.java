package springbootawsexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAwsExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
